COMP3308 Assignment 1
